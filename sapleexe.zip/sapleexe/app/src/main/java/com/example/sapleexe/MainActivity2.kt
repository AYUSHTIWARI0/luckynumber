package com.example.sapleexe

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.util.Random

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        val text1 : TextView = findViewById(R.id.textView3)
        val button :Button = findViewById(R.id.button2)

        var name = reciveusername()
        Toast.makeText(this, ""+name, Toast.LENGTH_SHORT).show()
        var random_no = randomno()
        text1.setText(""+random_no)

        button.setOnClickListener(){
            sharedata(name,random_no)
        }
    }

    fun reciveusername():String{
        var bundle:Bundle? = intent.extras
        var name1 = bundle?.get("name").toString()
        return name1
    }
    fun randomno():Int{
        val random = Random().nextInt(1000)
        return random
    }

    //shareing the result'
    fun sharedata(name:String,num:Int){
        var i =Intent(Intent.ACTION_SEND)
        i.setType("text/plain")
        i.putExtra(Intent.EXTRA_SUBJECT,""+name+"is lucky today")
        i.putExtra(Intent.EXTRA_TEXT,"his lucky number is $num")
        startActivity(i)
    }
}