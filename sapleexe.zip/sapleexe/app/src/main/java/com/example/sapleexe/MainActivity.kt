package com.example.sapleexe

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    var counter = 0
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        val b1 :Button = findViewById(R.id.button)
        val edttxt :EditText= findViewById(R.id.name)

        b1.setOnClickListener(){
            var name = edttxt.text

            var i = Intent (this,
                MainActivity2::class.java)
            i.putExtra("name", name)

            startActivity(i)
        }






//        var namr : EditText = findViewById(R.id.name)
//        var btn : Button = findViewById(R.id.button)
//        btn.setOnClickListener(){
//           val intent=Intent(this,MainActivity2::class.java)
//            startActivity(intent)
//
//
//        }





    }
}

